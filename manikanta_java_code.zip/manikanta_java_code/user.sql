
sql/>create table userreg(name varchar2(40),pass varchar2(40)); 


sql/>create table contacts (name varchar2(40),email varchar2(40),phone int(20));